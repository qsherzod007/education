create
    definer = root@localhost procedure MijozlarRuyxati()
BEGIN
    SELECT
        customerName, city, state, postalCode, country
    FROM
        customers
    ORDER BY customerName;
END;

